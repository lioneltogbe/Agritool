import React, { useState, useEffect } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { evaluationAPI } from '../../api';
import './EvaluationPage.css';
//import SystemPage from '../System/SystemPage';
//import SystemForm from '../System/SystemForm';

// Interfaces TypeScript (corrigées pour correspondre à l'API)
interface Category {
  id: number;
  nom: string;
  created_at?: string;
  updated_at?: string;
}

interface SousCategory {
  id: number;
  nom: string;
  category_id: number;
  created_at?: string;
  updated_at?: string;
}

interface Evaluation {
  id: number;
  titre: string;
  type: 'technologie' | 'systeme';
  path: string;
  categorie_id: number;
  created_at?: string;
  updated_at?: string;
}

interface Critere {
  id: number;
  nom: string;
  categorie_id: number;
  created_at?: string;
  updated_at?: string;
}

interface Indicateur {
  id: number;
  nom: string;
  poids: number;
  critere_id: number;
  created_at?: string;
  updated_at?: string;
}

interface Niveau {
  id: number;
  nom: string;
  value: number;
  indicateur_id: number;
  created_at?: string;
  updated_at?: string;
}


interface EvaluationSession {
  id?: number;
  user_id: number;
  evaluation_id: number;
  date_evaluation: string;
  created_at?: string;
  updated_at?: string;
}

const EvaluationPage = () => {
  // États pour la gestion des données
  const [categories, setCategories] = useState<Category[]>([]);
  const [sousCategories, setSousCategories] = useState<SousCategory[]>([]);
  const [evaluations, setEvaluations] = useState<Evaluation[]>([]);
  const [criteres, setCriteres] = useState<Critere[]>([]);
  const [indicateurs, setIndicateurs] = useState<Indicateur[]>([]);
  const [niveaux, setNiveaux] = useState<Niveau[]>([]);
  
  // États pour la navigation et la sélection
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedSousCategory, setSelectedSousCategory] = useState<number | null>(null);
  const [selectedEvaluation, setSelectedEvaluation] = useState<Evaluation | null>(null);
  const [scores, setScores] = useState<Record<number, number>>({});
 // const [view, setView] = useState<'register' | 'categories' | 'evaluations' | 'form' | 'results'>('register');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);


  const [view, setView] = useState<'SystemForm'|'register' | 'categories'| 'souscategories' | 'evaluations' | 'typeSelection' | 'form' | 'results' | 'system'>('register');
// const [systemSessions, setSystemSessions] = useState<any[]>([]);
// const [systemUser, setSystemUser] = useState<any>(null)
  // États pour le formulaire d'inscription
  const [userForm, setUserForm] = useState({
    nom: '',
    prenom: '',
    telephone: '',
    email: '',
    ville: '',
    pays: ''
  });

  // États pour la session
  const [currentSession, setCurrentSession] = useState<EvaluationSession | null>(null);
  //const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Chargement initial des catégories
  useEffect(() => {
    const initLoad = async () => {
      try {
        setLoading(true);
        const response = await evaluationAPI.getCategories();
        setCategories(response.data);
        setError(null);
      } catch (err) {
        setError('Erreur lors du chargement des catégories');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    initLoad();
  }, []);

  //charger les sous categories quand une categorie est selectionné
  
    const loadSousCategories = async (categoryId: number) => {  
      try {
        setLoading(true);
        const response = await evaluationAPI.getSousCategories(categoryId);
        setSousCategories(response.data);
        setView('souscategories');
        setError(null);
      } catch (err) {
        setError('Erreur lors du chargement des sous-catégories');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    useEffect(() => {
      if (selectedCategory !== null) {
        loadSousCategories(selectedCategory);
      }
    }, [selectedCategory]);

  // Charger les évaluations quand une sous-catégorie est sélectionnée
  useEffect(() => {
    if (selectedSousCategory !== null) {
      loadEvaluations(selectedSousCategory);
    }
  }, [selectedSousCategory]);

  // Gestionnaire pour le formulaire d'inscription
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Soumission du formulaire d'inscription
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setView('categories');
  };

  // Fonctions de chargement des données
  const loadEvaluations = async (selectedSousCategory: number) => {
    try {
      setLoading(true);
      const response = await evaluationAPI.getEvaluationsBySousCategory(selectedSousCategory);
      
      setEvaluations(response.data);
      setView('evaluations');
      setError(null);
    } catch (err) {
      setError('Erreur lors du chargement des évaluations');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Sélection d'une évaluation et création de la session
  const handleSelectEvaluation = async (evaluation: Evaluation) => {
    try {
      setLoading(true);
      setSelectedEvaluation(evaluation);
      
      // Créer l'utilisateur et la session en une seule opération
      const response = await evaluationAPI.createUserAndSession({
        user: {
          nom: userForm.nom,
          prenom: userForm.prenom,
          email: userForm.email,
          telephone: userForm.telephone,
          ville: userForm.ville,
          pays: userForm.pays,
        },
        evaluation_id: evaluation.id
      });
      setCurrentSession(response.data.session);
      //setCurrentUser(response.data.user);
      
      // Charger les détails de l'évaluation
      const criteresResponse = await evaluationAPI.getCriteresByCategory(evaluation.categorie_id);
      setCriteres(criteresResponse.data);
      
      // Charger les indicateurs pour chaque critère
      const indicateursPromises = criteresResponse.data.map(critere =>
        evaluationAPI.getIndicateursByCritere(critere.id)
      );
      
      const indicateursResponses = await Promise.all(indicateursPromises);
      const allIndicateurs = indicateursResponses.flatMap(response => response.data);
      setIndicateurs(allIndicateurs);
      
      // Charger les niveaux pour chaque indicateur
      const niveauxPromises = allIndicateurs.map(indicateur =>
        evaluationAPI.getNiveauxByIndicateur(indicateur.id)
      );
      
      const niveauxResponses = await Promise.all(niveauxPromises);
      const allNiveaux = niveauxResponses.flatMap(response => response.data);
      setNiveaux(allNiveaux);
      
      setView('form');
      setError(null);
    } catch (err) {
      setError('Erreur lors du démarrage de l\'évaluation');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleScoreChange = (indicateurId: number, niveauValue: number) => {
    setScores(prev => ({
      ...prev,
      [indicateurId]: niveauValue
    }));
  };

  const handleSubmitEvaluation = async () => {
    if (Object.keys(scores).length === indicateurs.length && currentSession && currentSession.id) {
      try {
        // Préparer les données des scores
        const scoresData = Object.entries(scores).map(([indicateurId, score]) => ({
          session_id: currentSession.id as number,
          indicateur_id: parseInt(indicateurId),
          score_obtenu: score,
          commentaire: ''
        }));
        console.log('Données envoyés scores obtenu', scoresData);
        // Enregistrer tous les scores
        const response = await evaluationAPI.saveIndicatorScores(scoresData);
        console.log('reponse envoyé au serveur', response.data.scores);
        setView('results');
        setError(null);
      } catch (error) {
        setError('Erreur lors de la sauvegarde des scores');
      }
    } else {
      setError('Veuillez compléter tous les indicateurs avant de soumettre');
    }
  };

  const handleNewEvaluation = () => {
    setSelectedCategory(null);
    setSelectedSousCategory(null);
    setSelectedEvaluation(null);
    setScores({});
    setCurrentSession(null);
    //setCurrentUser(null);
    setView('register');
  };

  const handleBack = () => {
    if (view === 'categories') {
      setView('register');
    } else if (view === 'souscategories') {
      setView('categories');
    } else if (view === 'evaluations') {
      setView('souscategories');
    } else if (view === 'form') {
      setView('evaluations');
    } else if (view === 'results') {
      setView('form');
    }
  };

  // Calcul des données pour le graphique
  const getChartData = () => {
    const dataByCritere: Record<number, { name: string; score: number; scoreMax: number }> = {};
    
    Object.entries(scores).forEach(([indicateurId, score]) => {
      const indicateur = indicateurs.find(i => i.id === parseInt(indicateurId));
      if (!indicateur) return;
      
      const critere = criteres.find(c => c.id === indicateur.critere_id);
      if (!critere) return;
      
      if (!dataByCritere[critere.id]) {
        dataByCritere[critere.id] = {
          name: critere.nom,
          score: 0,
          scoreMax: 0
        };
      }
      
      const scorePondere = score * indicateur.poids;
      const scoreMaxPondere = 5 * indicateur.poids;
      
      dataByCritere[critere.id].score += scorePondere;
      dataByCritere[critere.id].scoreMax += scoreMaxPondere;
    });
    
    return Object.values(dataByCritere).map(item => ({
      ...item,
      percentage: ((item.score / item.scoreMax) * 100).toFixed(1)
    }));
  };

  // Rendu conditionnel en fonction de la vue actuelle
  const renderContent = () => {
    if (loading) {
      return <div className="loading">Chargement...</div>;
    }

    if (error) {
      return (
        <div className="error">
          <p>{error}</p>
          <button onClick={() => setError(null)} className="primary-btn">
            OK
          </button>
        </div>
      );
    }

    switch (view) {
      case 'register':
        return (
          <div className="register-container">
            <h2>Enregistrer vous pour faire votre Evalution</h2>
            
            <form onSubmit={handleRegisterSubmit} className="register-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Nom *</label>
                  <input
                    type="text"
                    name="nom"
                    value={userForm.nom}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label>Prénom *</label>
                  <input
                    type="text"
                    name="prenom"
                    value={userForm.prenom}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Email *</label>
                  <input
                    type="email"
                    name="email"
                    value={userForm.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label>Contact *</label>
                  <input
                    type="text"
                    name="telephone"
                    value={userForm.telephone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Ville *</label>
                  <input
                    type="text"
                    name="ville"
                    value={userForm.ville}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                 <div className="form-group">
                  <label>Pays *</label>
                  <input
                    type="text"
                    name="pays"
                    value={userForm.pays}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <button type="submit" className="primary-btn">
                Enregistrer
              </button>
            </form>
          </div>
        );

      case 'categories':
        return (
          <div className="categories-container">
            <h2>Sélectionnez une catégorie d'évaluation</h2>
            <div className="categories-grid">
              {categories.map(category => (
                <div
                  key={category.id}
                  className="category-card"
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <h3>{category.nom}</h3>
                </div>
              ))}
            </div>
            <button onClick={handleBack} className="back-button">
              Retour aux informations
            </button>
          </div>
        );

      case 'souscategories':
        return (
          <div className="categories-container">
            <h2>Sélectionnez une sous catégorie d'évaluation</h2>
            <div className="categories-grid">
              {sousCategories.map(souscategory => (
                <div
                  key={souscategory.id}
                  className="category-card"
                  onClick={() => setSelectedSousCategory(souscategory.id)}
                >
                  <h3>{souscategory.nom}</h3>
                </div>
              ))}
            </div>
            <button onClick={handleBack} className="back-button">
              Retour aux catégories
            </button>
          </div>
        );

      case 'evaluations':
        return (
          <div className="evaluations-container">
            <h2>Évaluations disponibles</h2>
            <div className="evaluations-grid">
              {evaluations.map(evaluation => (
                <div
                  key={evaluation.id}
                  className="evaluation-card"
                  onClick={() => handleSelectEvaluation(evaluation)}
                >
                  <h3>{evaluation.titre}</h3>
                </div>
              ))}
            </div>
            <button onClick={handleBack} className="back-button">
              Retour aux catégories
            </button>
          </div>
        );

      case 'form':
        return (
          <div className="form-container">
            <h2>{selectedEvaluation?.titre}</h2>
            
            <div className="progress-container">
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ 
                    width: `${(Object.keys(scores).length / indicateurs.length) * 100}%` 
                  }}
                />
              </div>
              <span>
                {Object.keys(scores).length} / {indicateurs.length} indicateurs complétés
              </span>
            </div>

            {criteres.map(critere => {
              const critereIndicateurs = indicateurs.filter(i => i.critere_id === critere.id);
              if (critereIndicateurs.length === 0) return null;
              
              return (
                <div key={critere.id} className="critere-section">
                  <h3>{critere.nom}</h3>
                  
                  {critereIndicateurs.map(indicateur => {
                    const indicateurNiveaux = niveaux
                      .filter(n => n.indicateur_id === indicateur.id)
                      .sort((a, b) => a.value - b.value);
                    
                    return (
                      <div key={indicateur.id} className="indicateur-group">
                        <h4>{indicateur.nom}</h4>
                        
                        <div className="niveaux-container">
                          {indicateurNiveaux.map(niveau => (
                            <label
                              key={niveau.id}
                              className={`niveau-option ${scores[indicateur.id] === niveau.value ? 'selected' : ''}`}
                            >
                              <input
                                type="radio"
                                name={`indicateur-${indicateur.id}`}
                                value={niveau.value}
                                checked={scores[indicateur.id] === niveau.value}
                                onChange={() => handleScoreChange(indicateur.id, niveau.value)}
                              />
                              <div className="niveau-content">
                                <span className="niveau-description">{niveau.nom}</span>
                              </div>
                            </label>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })}

            <div className="form-actions">
              <button onClick={handleBack} className="back-button">Retour</button>
              <button 
                onClick={handleSubmitEvaluation}
                disabled={Object.keys(scores).length !== indicateurs.length}
                className="primary-btn"
              >
                Voir les résultats
              </button>
            </div>
          </div>
        );

      case 'results':
        const chartData = getChartData();
        const totalScore = chartData.reduce((sum, item) => sum + item.score, 0);
        const totalMaxScore = chartData.reduce((sum, item) => sum + item.scoreMax, 0);
        const totalPercentage = ((totalScore / totalMaxScore) * 100).toFixed(1);

        return (
          <div className="results-container">
            <h2>Résultats de l'évaluation</h2>
            <p className="overall-score">
              Score global: {totalScore.toFixed(2)}/{totalMaxScore.toFixed(2)} ({totalPercentage}%)
            </p>

            <div className="chart-container">
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number, name: string) => {
                      if (name === 'score') return [value.toFixed(2), 'Score'];
                      if (name === 'scoreMax') return [value.toFixed(2), 'Maximum'];
                      return value;
                    }}
                  />
                  <Legend />
                  <Bar dataKey="score" name="Score obtenu" fill="#4caf50" />
                  <Bar dataKey="scoreMax" name="Score maximum" fill="#ff9800" opacity={0.3} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="results-details">
              <h3>Détails par critère</h3>
              <div className="details-grid">
                {chartData.map((item, index) => (
                  <div key={index} className="detail-item">
                    <h4>{item.name}</h4>
                    <div className="score-detail">
                      <span className="score">{item.score.toFixed(2)}</span>
                      <span className="separator">/</span>
                      <span className="max-score">{item.scoreMax.toFixed(2)}</span>
                    </div>
                    <div className="percentage">{item.percentage}%</div>
                    <div className="progress-bar">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${item.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="results-actions">
              <button onClick={handleBack} className="back-button">Modifier l'évaluation</button>
              <button onClick={handleNewEvaluation} className="primary-btn">
                Nouvelle évaluation
              </button>
            </div>
          </div>
        );

      default:
        return <div>Vue non reconnue</div>;
    }
  };

  return (
    <div className="evaluation-container">
      <header className="evaluation-header">
        <h1>Évaluez vos pratiques agricoles</h1>
        {view !== 'register' && (
          <button onClick={handleNewEvaluation} className="home-button">
            Nouvelle évaluation
          </button>
        )}
      </header>

      <main className="evaluation-main">
        {renderContent()}
      </main>
    </div>
  );
};

export default EvaluationPage;