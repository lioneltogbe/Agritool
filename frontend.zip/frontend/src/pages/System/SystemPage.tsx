import React, { useState, useEffect } from 'react';
import { evaluationAPI } from '../../api';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import './SystemPage.css';

interface SousCategory {
  id: number;
  nom: string;
  category_id: number;
  created_at?: string;
  updated_at?: string;
}

const SystemPage: React.FC = () => {
  const [view, setView] = useState<'register' | 'categories' |'souscategories'| 'evaluations' | 'form' | 'results'>('register');
  const [userForm, setUserForm] = useState({
    nom: '',
    prenom: '',
    email: '',
    telephone: '',
    ville: '',
    pays: ''
  });
  const [categories, setCategories] = useState<any[]>([]);
  const [sousCategories, setSousCategories] = useState<SousCategory[]>([]);
  const [evaluations, setEvaluations] = useState<any[]>([]);
  const [selectedEvaluations, setSelectedEvaluations] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedSousCategory, setSelectedSousCategory] = useState<number | null>(null);
  // États pour la gestion des évaluations
  const [sessions, setSessions] = useState<any[]>([]);
  const [currentSessionIndex, setCurrentSessionIndex] = useState<number>(0);
  const [selectedEvaluation, setSelectedEvaluation] = useState<any>(null);
  const [criteres, setCriteres] = useState<any[]>([]);
  const [indicateurs, setIndicateurs] = useState<any[]>([]);
  const [niveaux, setNiveaux] = useState<any[]>([]);
  const [scores, setScores] = useState<Record<string, number>>({});
  const [allScores, setAllScores] = useState<Record<number, Record<string, number>>>({});
  const [resultsData, setResultsData] = useState<any[]>([]);

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      setLoading(true);
      const response = await evaluationAPI.getCategories();
      setCategories(response.data);
      setError(null);
    } catch (err) {
      setError('Erreur lors du chargement des catégories');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
        if (selectedCategory !== null) {
          loadSousCategories(selectedCategory);
        }
      }, [selectedCategory]);

  //charger les sous categories quand une categorie est selectionné

    useEffect(() => {
      if (selectedSousCategory !== null) {
        loadEvaluations(selectedSousCategory);
      }
    }, [selectedSousCategory]);

  const loadSousCategories = async (categoryId: number) => {  
        try {
          setLoading(true);
          const response = await evaluationAPI.getSousCategories(categoryId);
          setSousCategories(response.data);
          setView('souscategories');
          setError(null);
        } catch (err) {
          setError('Erreur lors du chargement des sous-catégories');
          console.error(err);
        } finally {
          setLoading(false);
        }
      };

  const loadEvaluations = async (souscategoryId: number) => {
    try {
      setLoading(true);
      const response = await evaluationAPI.getEvaluationsBySousCategory(souscategoryId);
      setEvaluations(response.data);
      setSelectedSousCategory(souscategoryId);
      setView('evaluations');
      setError(null);
    } catch (err) {
      setError('Erreur lors du chargement des évaluations');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadEvaluationData = async (evaluation: any) => {
    try {
      setLoading(true);
      setSelectedEvaluation(evaluation);
      
      // Charger les critères par catégorie de l'évaluation
      const criteresResponse = await evaluationAPI.getCriteresByCategory(evaluation.categorie_id);
      setCriteres(criteresResponse.data);
      
      // Charger les indicateurs pour chaque critère
      const indicateursPromises = criteresResponse.data.map(critere =>
        evaluationAPI.getIndicateursByCritere(critere.id)
      );
      
      const indicateursResponses = await Promise.all(indicateursPromises);
      const allIndicateurs = indicateursResponses.flatMap(response => response.data);
      setIndicateurs(allIndicateurs);
      
      // Charger les niveaux pour chaque indicateur
      const niveauxPromises = allIndicateurs.map(indicateur =>
        evaluationAPI.getNiveauxByIndicateur(indicateur.id)
      );
      
      const niveauxResponses = await Promise.all(niveauxPromises);
      const allNiveaux = niveauxResponses.flatMap(response => response.data);
      setNiveaux(allNiveaux);
      
      // Charger les scores existants si disponibles
      const currentSessionId = sessions[currentSessionIndex]?.id;
      if (currentSessionId && allScores[currentSessionId]) {
        setScores(allScores[currentSessionId]);
      } else {
        setScores({});
      }
      
      setView('form');
      setError(null);
    } catch (err) {
      setError('Erreur lors du démarrage de l\'évaluation');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userForm.nom || !userForm.prenom || !userForm.email || !userForm.telephone || !userForm.ville || !userForm.pays) {
      setError('Veuillez remplir tous les champs obligatoires');
      return;
    }
    setView('categories');
    setError(null);
  };

  const handleSelectEvaluation = (evaluation: any) => {
    if (selectedEvaluations.some(e => e.id === evaluation.id)) {
      setSelectedEvaluations(selectedEvaluations.filter(e => e.id !== evaluation.id));
      return;
    }

    if (selectedEvaluations.length < 2) {
      setSelectedEvaluations([...selectedEvaluations, evaluation]);
    } else {
      setError('Vous ne pouvez sélectionner que deux évaluations maximum');
    }
  };

  const handleCreateSystem = async () => {
    if (selectedEvaluations.length !== 2) {
      setError('Veuillez sélectionner exactement deux évaluations');
      return;
    }

    try {
      setLoading(true);
      
      const response = await evaluationAPI.createSystemEvaluation({
        user: {
          nom: userForm.nom,
          prenom: userForm.prenom,
          email: userForm.email,
          telephone: userForm.telephone,
          ville: userForm.ville,
          pays: userForm.pays,
        },
        evaluation_ids: selectedEvaluations.map(e => e.id)
      });

      setSessions(response.data.sessions);
      setCurrentSessionIndex(0);
      const firstEvaluation = selectedEvaluations.find(e => e.id === response.data.sessions[0].evaluation_id);
      if (firstEvaluation) {
        await loadEvaluationData(firstEvaluation);
      }
      
    } catch (err: any) {
      console.error('Erreur création système:', err);
      setError(err.response?.data?.message || 'Erreur lors de la création du système');
    } finally {
      setLoading(false);
    }
  };

  const handleScoreChange = (indicateurId: string, value: number) => {
    setScores(prev => ({
      ...prev,
      [indicateurId]: value
    }));
  };

  const handleSubmitEvaluation = async () => {
    try {
      setLoading(true);
      
      // Sauvegarder les scores pour cette session
      const currentSessionId = sessions[currentSessionIndex].id;
      setAllScores(prev => ({
        ...prev,
        [currentSessionId]: { ...scores }
      }));
      
      // Préparer les données de score pour l'API
      const scoresData = Object.entries(scores).map(([indicateurId, score]) => ({
        session_id: currentSessionId,
        indicateur_id: parseInt(indicateurId),
        score_obtenu: score
      }));
      
      // Envoyer les scores au serveur
      await evaluationAPI.saveIndicatorScores(scoresData);
      
      // Passer à l'évaluation suivante ou aux résultats
      if (currentSessionIndex < sessions.length - 1) {
        const nextIndex = currentSessionIndex + 1;
        setCurrentSessionIndex(nextIndex);
        const nextEvaluation = selectedEvaluations.find(e => e.id === sessions[nextIndex].evaluation_id);
        if (nextEvaluation) {
          await loadEvaluationData(nextEvaluation);
        }
      } else {
        // Toutes les évaluations sont complétées, charger les résultats
        await loadResultsData();
        setView('results');
      }
    } catch (err: any) {
      console.error('Erreur soumission des scores:', err);
      setError(err.response?.data?.message || 'Erreur lors de la soumission des scores');
    } finally {
      setLoading(false);
    }
  };

  const loadResultsData = async () => {
    try {
      setLoading(true);
      // Récupérer les scores pour toutes les sessions
      const sessionIds = sessions.map(session => session.id);
      const results = await evaluationAPI.getSessionsScores(sessionIds);
      setResultsData(results.data);
    } catch (err) {
      setError('Erreur lors du chargement des résultats');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getChartData = (sessionIndex: number) => {
    const session = sessions[sessionIndex];
    if (!session || !resultsData[sessionIndex]) return [];
    
    const evaluation = selectedEvaluations.find(e => e.id === session.evaluation_id);
    if (!evaluation) return [];
    
    // Cette logique devrait être adaptée selon la structure de vos données
    return criteres.map(critere => {
      const critereIndicateurs = indicateurs.filter(i => i.critere_id === critere.id);
      const scoreMax = critereIndicateurs.reduce((sum, indicateur) => {
        const indicateurNiveaux = niveaux.filter(n => n.indicateur_id === indicateur.id);
        const maxNiveau = Math.max(...indicateurNiveaux.map(n => n.value));
        return sum + maxNiveau;
      }, 0);
      
      const score = critereIndicateurs.reduce((sum, indicateur) => {
        return sum + (resultsData[sessionIndex]?.scores?.[indicateur.id] || 0);
      }, 0);
      
      const percentage = scoreMax > 0 ? Math.round((score / scoreMax) * 100) : 0;
      
      return {
        name: critere.nom,
        score,
        scoreMax,
        percentage
      };
    });
  };

  const handleBackToCategories = () => {
    setView('categories');
    setEvaluations([]);
    setSelectedCategory(null);
    setSelectedSousCategory(null);
  };

  const handleBackToEvaluations = () => {
    setView('evaluations');
  };

  const handleNewEvaluation = () => {
    setView('categories');
    setSelectedEvaluations([]);
    setSessions([]);
    setAllScores({});
    setResultsData([]);
  };

  const renderContent = () => {
    switch (view) {
      case 'register':
        return (
          <div className="register-container">
            <h2>Enregistrez-vous pour faire votre Évaluation systeme</h2>
            
            <form onSubmit={handleRegisterSubmit} className="register-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Nom *</label>
                  <input
                    type="text"
                    name="nom"
                    value={userForm.nom}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label>Prénom *</label>
                  <input
                    type="text"
                    name="prenom"
                    value={userForm.prenom}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Email *</label>
                  <input
                    type="email"
                    name="email"
                    value={userForm.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label>Contact *</label>
                  <input
                    type="text"
                    name="telephone"
                    value={userForm.telephone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Ville *</label>
                  <input
                    type="text"
                    name="ville"
                    value={userForm.ville}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                 <div className="form-group">
                  <label>Pays *</label>
                  <input
                    type="text"
                    name="pays"
                   value={userForm.pays}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <button type="submit" className="primary-btn">
                Enregistrer
              </button>
            </form>
          </div>
        );

      case 'categories':
        return (
          <div className="categories-section">
            <h3>Sélectionnez une catégorie pour choisir vos évaluations</h3>
            <div className="categories-grid">
              {categories.map(category => (
                <div
                  key={category.id}
                  className="category-card"
                  onClick={() => loadSousCategories(category.id)}
                >
                  <h4>{category.nom}</h4>
                </div>
              ))}
            </div>
          </div>
        );
      
       case 'souscategories':
        return (
          <div className="categories-section">
            <h3>Sélectionnez une sous catégorie pour choisir vos évaluations</h3>
            <div className="categories-grid">
              {sousCategories.map(souscategory => (
                <div
                  key={souscategory.id}
                  className="category-card"
                  onClick={() => loadEvaluations(souscategory.id)}
                >
                  <h4>{souscategory.nom}</h4>
                </div>
              ))}
            </div>
          </div>
        );

      case 'evaluations':
        return (
          <div className="evaluations-section">
            <h3>
              Sélectionnez deux évaluations pour votre système 
              {selectedCategory && ` (Catégorie: ${categories.find(c => c.id === selectedCategory)?.nom})`}
            </h3>
            
            <div className="evaluations-grid">
              {evaluations.map(evaluation => (
                <div
                  key={evaluation.id}
                  className={`evaluation-card ${
                    selectedEvaluations.some(e => e.id === evaluation.id) ? 'selected' : ''
                  }`}
                  onClick={() => handleSelectEvaluation(evaluation)}
                >
                  <h4>{evaluation.titre}</h4>
                  <div className="selection-indicator">
                    {selectedEvaluations.some(e => e.id === evaluation.id) ? '✓' : ''}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'form':
        return (
          <div className="form-container">
            <h2>{selectedEvaluation?.titre} - Session {currentSessionIndex + 1}</h2>
            
            <div className="progress-container">
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ 
                    width: `${(Object.keys(scores).length / indicateurs.length) * 100}%` 
                  }}
                />
              </div>
              <span>
                {Object.keys(scores).length} / {indicateurs.length} indicateurs complétés
              </span>
            </div>

            {criteres.map(critere => {
              const critereIndicateurs = indicateurs.filter(i => i.critere_id === critere.id);
              if (critereIndicateurs.length === 0) return null;
              
              return (
                <div key={critere.id} className="critere-section">
                  <h3>{critere.nom}</h3>
                  
                  {critereIndicateurs.map(indicateur => {
                    const indicateurNiveaux = niveaux
                      .filter(n => n.indicateur_id === indicateur.id)
                      .sort((a, b) => a.value - b.value);
                    
                    return (
                      <div key={indicateur.id} className="indicateur-group">
                        <h4>{indicateur.nom}</h4>
                        
                        <div className="niveaux-container">
                          {indicateurNiveaux.map(niveau => (
                            <label
                              key={niveau.id}
                              className={`niveau-option ${scores[indicateur.id] === niveau.value ? 'selected' : ''}`}
                            >
                              <input
                                type="radio"
                                name={`indicateur-${indicateur.id}`}
                                value={niveau.value}
                                checked={scores[indicateur.id] === niveau.value}
                                onChange={() => handleScoreChange(indicateur.id, niveau.value)}
                              />
                              <div className="niveau-content">
                                <span className="niveau-description">{niveau.nom}</span>
                              </div>
                            </label>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })}

            <div className="form-actions">
              <button onClick={handleBackToEvaluations} className="back-button">Retour</button>
              <button 
                onClick={handleSubmitEvaluation}
                disabled={Object.keys(scores).length !== indicateurs.length}
                className="primary-btn"
              >
                {currentSessionIndex < sessions.length - 1 ? 'Évaluation suivante' : 'Voir les résultats'}
              </button>
            </div>
          </div>
        );

      case 'results':
        return (
          <div className="results-container">
            <h2>Résultats des évaluations</h2>
            
            <div className="evaluations-comparison">
              {sessions.map((session, index) => {
                const evaluation = selectedEvaluations.find(e => e.id === session.evaluation_id);
                const chartData = getChartData(index);
                const totalScore = chartData.reduce((sum, item) => sum + item.score, 0);
                const totalMaxScore = chartData.reduce((sum, item) => sum + item.scoreMax, 0);
                const totalPercentage = totalMaxScore > 0 ? ((totalScore / totalMaxScore) * 100).toFixed(1) : 0;

                return (
                  <div key={session.id} className="evaluation-result">
                    <h3>{evaluation?.titre}</h3>
                    <p className="overall-score">
                      Score global: {totalScore.toFixed(2)}/{totalMaxScore.toFixed(2)} ({totalPercentage}%)
                    </p>

                    <div className="chart-container">
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip 
                            formatter={(value: number, name: string) => {
                              if (name === 'score') return [value.toFixed(2), 'Score'];
                              if (name === 'scoreMax') return [value.toFixed(2), 'Maximum'];
                              return value;
                            }}
                          />
                          <Legend />
                          <Bar dataKey="score" name="Score obtenu" fill={index === 0 ? "#4caf50" : "#2196f3"} />
                          <Bar dataKey="scoreMax" name="Score maximum" fill="#ff9800" opacity={0.3} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="results-details">
                      <h4>Détails par critère</h4>
                      <div className="details-grid">
                        {chartData.map((item, idx) => (
                          <div key={idx} className="detail-item">
                            <h5>{item.name}</h5>
                            <div className="score-detail">
                              <span className="score">{item.score.toFixed(2)}</span>
                              <span className="separator">/</span>
                              <span className="max-score">{item.scoreMax.toFixed(2)}</span>
                            </div>
                            <div className="percentage">{item.percentage}%</div>
                            <div className="progress-bar">
                              <div 
                                className="progress-fill" 
                                style={{ width: `${item.percentage}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="results-actions">
              <button onClick={handleNewEvaluation} className="primary-btn">
                Nouvelle évaluation
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (loading && view !== 'register' && view !== 'form') {
    return <div className="loading">Chargement...</div>;
  }

  return (
    <div className="system-page-container">
      <div className="system-header">
        <button onClick={() => {
          if (view === 'categories') {
            setView('register');
          } else if (view === 'souscategories') {
            setView('categories');
          } else if (view === 'evaluations') {
            handleBackToCategories();
          } else if (view === 'form') {
            if (currentSessionIndex > 0) {
              const prevIndex = currentSessionIndex - 1;
              setCurrentSessionIndex(prevIndex);
              const prevEvaluation = selectedEvaluations.find(e => e.id === sessions[prevIndex].evaluation_id);
              if (prevEvaluation) {
                loadEvaluationData(prevEvaluation);
              }
            } else {
              setView('evaluations');
            }
          } else if (view === 'results') {
            setView('form');
          }
        }} className="back-button">
          &larr; Retour
        </button>
        <h2>Système d'Évaluation</h2>
        {view !== 'register' && view !== 'form' && view !== 'results' && (
          <div className="selected-count">
            {selectedEvaluations.length}/2 sélectionnées
          </div>
        )}
      </div>

      {error && (
        <div className="error">
          {error}
          <button onClick={() => setError(null)} className="dismiss-button">
            ×
          </button>
        </div>
      )}

      {renderContent()}

      {view === 'evaluations' && selectedEvaluations.length > 0 && (
        <div className="selected-evaluations">
          <h4>Évaluations sélectionnées pour votre système:</h4>
          <ul>
            {selectedEvaluations.map(evaluation => (
              <li key={evaluation.id}>
                <span className="eval-title">{evaluation.titre}</span>
                <span className="eval-type">({evaluation.type})</span>
                <button
                  onClick={() => handleSelectEvaluation(evaluation)}
                  className="remove-button"
                >
                  ×
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {view === 'evaluations' && selectedEvaluations.length > 0 && (
        <div className="action-buttons">
          <button
            onClick={handleCreateSystem}
            className="primary-btn"
            disabled={selectedEvaluations.length !== 2 || loading}
          >
            {loading ? 'Création en cours...' : 'Créer le système d\'évaluation'}
          </button>
        </div>
      )}
    </div>
  );
};

export default SystemPage;