import React, { useState, useEffect } from 'react';
import { evaluationAPI } from '../../api';
import './SystemForm.css';

interface SystemFormProps {
  user: any;
  sessions: any[];
  onCompletion: (results: any) => void;
  onBack: () => void;
}

const SystemForm: React.FC<SystemFormProps> = ({ user, sessions, onCompletion, onBack }) => {
  const [currentEvaluationIndex, setCurrentEvaluationIndex] = useState(0);
  const [criteres, setCriteres] = useState<any[]>([]);
  const [indicateurs, setIndicateurs] = useState<any[]>([]);
  const [niveaux, setNiveaux] = useState<any[]>([]);
  const [scores, setScores] = useState<Record<number, number>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const currentSession = sessions[currentEvaluationIndex];
  const currentEvaluation = currentSession.evaluation;

  useEffect(() => {
    loadEvaluationDetails();
  }, [currentEvaluationIndex]);

  const loadEvaluationDetails = async () => {
    try {
      setLoading(true);
      
      // Charger les critères
      const criteresResponse = await evaluationAPI.getCriteresByCategory(currentEvaluation.categorie_id);
      setCriteres(criteresResponse.data);
      
      // Charger les indicateurs
      const indicateursPromises = criteresResponse.data.map(critere =>
        evaluationAPI.getIndicateursByCritere(critere.id)
      );
      
      const indicateursResponses = await Promise.all(indicateursPromises);
      const allIndicateurs = indicateursResponses.flatMap(response => response.data);
      setIndicateurs(allIndicateurs);
      
      // Charger les niveaux
      const niveauxPromises = allIndicateurs.map(indicateur =>
        evaluationAPI.getNiveauxByIndicateur(indicateur.id)
      );
      
      const niveauxResponses = await Promise.all(niveauxPromises);
      const allNiveaux = niveauxResponses.flatMap(response => response.data);
      setNiveaux(allNiveaux);
      
      setError(null);
    } catch (err) {
      setError('Erreur lors du chargement des détails de l\'évaluation');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleScoreChange = (indicateurId: number, niveauValue: number) => {
    setScores(prev => ({
      ...prev,
      [indicateurId]: niveauValue
    }));
  };

  const handleNextEvaluation = async () => {
    if (Object.keys(scores).length !== indicateurs.length) {
      setError('Veuillez compléter tous les indicateurs avant de continuer');
      return;
    }

    try {
      // Sauvegarder les scores de l'évaluation actuelle
      const scoresData = Object.entries(scores).map(([indicateurId, score]) => ({
        session_id: currentSession.id,
        indicateur_id: parseInt(indicateurId),
        score_obtenu: score,
        commentaire: ''
      }));

      await evaluationAPI.saveIndicatorScores(scoresData);
      
      // Passer à l'évaluation suivante ou terminer
      if (currentEvaluationIndex < sessions.length - 1) {
        setCurrentEvaluationIndex(prev => prev + 1);
        setScores({});
      } else {
        // Toutes les évaluations sont complétées
        onCompletion({ user, sessions });
      }
    } catch (err) {
      setError('Erreur lors de la sauvegarde des scores');
      console.error(err);
    }
  };

  const handlePreviousEvaluation = () => {
    if (currentEvaluationIndex > 0) {
      setCurrentEvaluationIndex(prev => prev - 1);
      setScores({});
    } else {
      onBack();
    }
  };

  if (loading) {
    return <div className="loading">Chargement de l'évaluation...</div>;
  }

  return (
    <div className="system-form-container">
      <div className="system-form-header">
        <button onClick={handlePreviousEvaluation} className="back-button">
          &larr; {currentEvaluationIndex > 0 ? 'Précédent' : 'Retour'}
        </button>
        
        <div className="evaluation-progress">
          <h2>Évaluation {currentEvaluationIndex + 1}/{sessions.length}</h2>
          <p>{currentEvaluation.titre}</p>
          <div className="progress-steps">
            {sessions.map((session, index) => (
              <div
                key={session.id}
                className={`progress-step ${index === currentEvaluationIndex ? 'active' : ''} ${index < currentEvaluationIndex ? 'completed' : ''}`}
              >
                {index + 1}
              </div>
            ))}
          </div>
        </div>
      </div>

      {error && (
        <div className="error">
          {error}
          <button onClick={() => setError(null)} className="dismiss-button">
            ×
          </button>
        </div>
      )}

      <div className="progress-container">
        <div className="progress-bar">
          <div 
            className="progress-fill" 
            style={{ 
              width: `${(Object.keys(scores).length / indicateurs.length) * 100}%` 
            }}
          />
        </div>
        <span>
          {Object.keys(scores).length} / {indicateurs.length} indicateurs complétés
        </span>
      </div>

      <div className="form-content">
        {criteres.map(critere => {
          const critereIndicateurs = indicateurs.filter(i => i.critere_id === critere.id);
          if (critereIndicateurs.length === 0) return null;
          
          return (
            <div key={critere.id} className="critere-section">
              <h3>{critere.nom}</h3>
              
              {critereIndicateurs.map(indicateur => {
                const indicateurNiveaux = niveaux
                  .filter(n => n.indicateur_id === indicateur.id)
                  .sort((a, b) => a.value - b.value);
                
                return (
                  <div key={indicateur.id} className="indicateur-group">
                    <h4>{indicateur.nom} (Poids: {indicateur.poids})</h4>
                    
                    <div className="niveaux-container">
                      {indicateurNiveaux.map(niveau => (
                        <label
                          key={niveau.id}
                          className={`niveau-option ${scores[indicateur.id] === niveau.value ? 'selected' : ''}`}
                        >
                          <input
                            type="radio"
                            name={`indicateur-${indicateur.id}`}
                            value={niveau.value}
                            checked={scores[indicateur.id] === niveau.value}
                            onChange={() => handleScoreChange(indicateur.id, niveau.value)}
                          />
                          <div className="niveau-content">
                            <span className="niveau-value">Niveau {niveau.value}</span>
                            <span className="niveau-description">{niveau.nom}</span>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>

      <div className="system-form-actions">
        <button 
          onClick={handleNextEvaluation}
          disabled={Object.keys(scores).length !== indicateurs.length}
          className="primary-btn"
        >
          {currentEvaluationIndex < sessions.length - 1 ? 'Évaluation suivante' : 'Terminer le système'}
        </button>
      </div>
    </div>
  );
};

export default SystemForm;