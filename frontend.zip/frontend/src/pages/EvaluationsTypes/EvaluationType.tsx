
import './EvaluationType.css';
import { Link } from 'react-router-dom';

const EvaluationType = () => {
    return (
        <div className="evaluation-type-container">
            <div className="type-selection-container">
                <h2>Sélectionnez le type d'évaluation</h2>
                
                <div className="type-buttons-container">
                    <Link to='/evaluation'>
                    <button className="type-button practices-technology-btn">
                     
                        <span className="button-title">Pratiques/Technologies</span>
                       
                    </button>
                    </Link>
                    <Link to='/systemePage'>
                    <button className="type-button practices-technology-btn">
                        <span className="button-title">Système</span>
                    </button>
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default EvaluationType;