import { BarChart3, Leaf, Search, Rocket } from "lucide-react";
import  './FeaturesSection.css';

export default function FeaturesSection() {
  return (
    <section className="features-section">
      <h2 className="features-title">
        Nos <span className="highlight">Avantages</span>
      </h2>
      <div className="features-container">
        <div className="feature-card">
          <BarChart3 className="icon" />
          <h3>Analyse intelligente des données</h3>
          <p>Transformez vos données agricoles en indicateurs clairs et exploitables.</p>
        </div>

        <div className="feature-card">
          <Leaf className="icon" />
          <h3>Pratiques durables</h3>
          <p>Adoptez des méthodes respectueuses de l’environnement et optimisez vos ressources.</p>
        </div>

        <div className="feature-card">
          <Search className="icon" />
          <h3>Comparaison et suivi</h3>
          <p>Visualisez vos résultats  et suivez vos progrès saison après saison.</p>
        </div>

        <div className="feature-card">
          <Rocket className="icon" />
          <h3>Décisions guidées par les données</h3>
          <p>Accédez à des recommandations et observations pour améliorer vos performances.</p>
        </div>
      </div>
    </section>
  );
}
