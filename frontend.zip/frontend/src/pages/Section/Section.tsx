import './Section.css';
import {Link} from 'react-router-dom';


const Section = () => {
    return (
        <section className="section">
            <div className='section-text'>
                <h1>Evaluez, Analysez et Améliorez vos Pratiques <span>Agricoles </span></h1>
                <p>
                    Un outil simple et fiable pour mesurer, comparer et améliorer vos pratiques agricoles.
                    Transformez vos données agricoles en informations utiles et exploitables à base des indicateurs clairs pour une agriculture plus performante et durable.
                </p>
                <div className=" section-buttons">
                    <Link to="/evaluation-type">
                        <button className="btn btn-primary">Faire une évaluation</button>
                    </Link>
                    <a href="#">
                        <button className="btn btn-secondary">Visuliser une évaluation</button>
                    </a>
                </div>
            </div>
            <div className='section-media'>
                
               
            </div>

            
        </section>
    );
};

export default Section;