import './AboutSection.css';


export default function AboutSection() {
  return (
    <section className="about-section">
      <div className="about-container">
        <div className="about-text">
          <h2 className="about-title">
            Pourquoi Agritool ?
          </h2>
          <p className="about-problem">
            De nombreux agriculteurs manquent d’outils simples pour comprendre et améliorer leurs pratiques.
            Agritool leur offre une solution claire : transformer leurs données en indicateurs utiles et
            les guider vers des choix plus performants et durables.
             Notre engagement est d’accompagner chaque producteur dans l’optimisation de son exploitation,
             afin de renforcer sa rentabilité tout en préservant l’environnement.
          </p>
        </div>
        <div className="about-image">
          <img src="/une-femme-photorealiste-dans-un-jardin-biologique-durable-recoltant-des-produits.jpg"  />
           <div className="play-button"> ▶</div>
        </div>
      </div>
    </section>
  );
}
