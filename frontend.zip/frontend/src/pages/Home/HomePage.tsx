// pages/Home/HomePage.tsx

import Section from '../Section/Section';
import FeaturesSection from '../Features/FeaturesSection';
import AboutSection from '../About/AboutSection';
import './HomePage.css';

const HomePage = () => {
  return (
    <div className="home">
      <Section />
      <FeaturesSection />
      <AboutSection />
    </div>
  );
};

export default HomePage;