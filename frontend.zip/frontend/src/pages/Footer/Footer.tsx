import './Footer.css';
export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">

        {/* Bloc gauche : logo + description */}
        <div className="footer-about">
          <h3 className="footer-logo">Agritool</h3>
          <p>
            Un logiciel simple et efficace pour analyser vos pratiques agricoles, 
            améliorer vos performances et contribuer à une agriculture durable.
          </p>
        </div>

        {/* Bloc centre : liens rapides */}
        <div className="footer-links">
          <h4>Liens utiles</h4>
          <ul>
            <li><a href="#">Accueil</a></li>
            <li><a href="#">Fonctionnalités</a></li>
            <li><a href="#">À propos</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </div>

        {/* Bloc droite : contact */}
        <div className="footer-contact">
          <h4>Contact</h4>
          <p>Email : support@agritool.com</p>
          <p>Tél : +229 00 00 00 00</p>
          <div className="socials">
            <a href="#"><i className="fab fa-facebook"></i></a>
            <a href="#"><i className="fab fa-whatsapp"></i></a>
            <a href="#"><i className="fab fa-twitter"></i></a>
          </div>
        </div>
      </div>

      {/* Bas du footer */}
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Agritool - Tous droits réservés</p>
      </div>
    </footer>
  );
}
