
import './Header.css';


const Header = () => {
    return (
        <header className="header">
            {/* logo */}
            <div className='Monlogo'>Agritool</div>

            {/* Navigation */}
            <nav className='nav'>
                <a href="#" className='nav-link'>Acceuil</a>
                <a href="#" className='nav-link'>Apropos</a>
                <a href="#" className='nav-link'>Services</a>
                <a href="#" className='nav-link'>Contact</a>
            </nav>

            {/* Boutton Sing up */}
            {/* <button className="btn-signup">Sign up</button> */}
        </header>
    );
};

export default Header;