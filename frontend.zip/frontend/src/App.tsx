import { BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Header from './pages/Header/Header';
import Footer from './pages/Footer/Footer';
import './App.css';
import EvaluationPage from './pages/Evaluations/EvaluationPage';
import HomePage from './pages/Home/HomePage';
import EvaluationType from './pages/EvaluationsTypes/EvaluationType';
import SystemPage from './pages/System/SystemPage';


function App() {
  return (
    <Router>
      <div className='App'>
        <Header />
        <div style={{ padding: '20px' }}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/evaluation" element={<EvaluationPage />} />
          <Route path="/evaluation-type" element={<EvaluationType/>} />
          <Route path="/systemePage" element={<SystemPage/>} />
        </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
}

export default App;