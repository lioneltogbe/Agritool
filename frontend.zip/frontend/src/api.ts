import axios from 'axios';

// Interfaces TypeScript
interface Category {
  id: number;
  nom: string;
  created_at?: string;
  updated_at?: string;
}

interface SousCategory {
  id: number;
  nom: string;
  category_id: number;
  created_at?: string;
  updated_at?: string;
}

interface Critere {
  id: number;
  nom: string;
  categorie_id: number;
  created_at?: string;
  updated_at?: string;
}

interface Indicateur {
  id: number;
  nom: string;
  poids: number;
  critere_id: number;
  created_at?: string;
  updated_at?: string;
}

interface Niveau {
  id: number;
  nom: string;
  value: number;
  indicateur_id: number;
  created_at?: string;
  updated_at?: string;
}

interface Evaluation {
  id: number;
  titre: string;
  type: 'technologie' | 'systeme';
  path: string;
  categorie_id: number;
  created_at?: string;
  updated_at?: string;
}

interface User {
  id: number;
  nom: string;
  prenom: string;
  email: string;
  telephone?: string;
  ville?: string;
  pays?: string;
  created_at?: string;
  updated_at?: string;
}

interface EvaluationSession {
  id?: number;
  user_id: number;
  evaluation_id: number;
  date_evaluation: string;
  created_at?: string;
  updated_at?: string;
}

interface SessionScore {
  session_id: number;
  scores: Record<number, number>; // indicateur_id: score
}

// interface IndicateurScore {
//   id: number;
//   session_id: number;
//   indicateur_id: number;
//   score_obtenu: number;
//   commentaire?: string;
//   created_at?: string;
//   updated_at?: string;
// }

// Configuration de l'API
const API_BASE_URL = 'http://127.0.0.1:8000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Intercepteur pour les erreurs
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('Erreur API:', error);
    return Promise.reject(error);
  }
);

// Service API
export const evaluationAPI = {
  // Récupérer toutes les catégories
  getCategories: (): Promise<{ data: Category[] }> => 
    api.get('/categories'),

  // Récupérer les sous-catégories d'une catégorie (NOUVELLE FONCTION)
  getSousCategories: (categoryId: number): Promise<{ data: SousCategory[] }> => 
    api.get(`/souscategories/${categoryId}`),


  // Récupérer les évaluations d'une catégorie (CORRIGÉ pour correspondre au contrôleur Laravel)
  getEvaluationsByCategory: (categoryId: number): Promise<{ data: Evaluation[] }> => 
    api.get(`/evaluations/${categoryId}`),

  // Récupérer les évaluations d'une sous-catégorie (NOUVELLE FONCTION)
  getEvaluationsBySousCategory: (souscategoryId: number): Promise<{ data: Evaluation[] }> => 
    api.get(`/souscategorie-evaluations/${souscategoryId}`),

  // Récupérer une évaluation spécifique
  getEvaluation: (id: number): Promise<{ data: Evaluation }> => 
    api.get(`/evaluation/${id}`),

  // Récupérer les critères d'une catégorie (CORRIGÉ pour correspondre au contrôleur Laravel)
  getCriteresByCategory: (categoryId: number): Promise<{ data: Critere[] }> => 
    api.get(`/criteres/${categoryId}`),

  // Récupérer les indicateurs d'un critère (CORRIGÉ pour correspondre au contrôleur Laravel)
  getIndicateursByCritere: (critereId: number): Promise<{ data: Indicateur[] }> => 
    api.get(`/indicateur/${critereId}`),

  // Récupérer les niveaux d'un indicateur (CORRIGÉ pour correspondre au contrôleur Laravel)
  getNiveauxByIndicateur: (indicateurId: number): Promise<{ data: Niveau[] }> => 
    api.get(`/niveau/${indicateurId}`),

  // NOUVELLE FONCTION: Créer un utilisateur et une session d'évaluation
  createUserAndSession: (data: {
    user: {

      nom: string;
      prenom: string;
      email: string;
      telephone: string;
      ville: string; 
      pays: string;
    };
    evaluation_id: number;
  }): Promise<{ data: { session: EvaluationSession; user: User } }> => 
    api.post('/users-with-session', data),

  // NOUVELLE FONCTION: Sauvegarder les scores des indicateurs
  saveIndicatorScores: (scoresData: {
    session_id: number;
    indicateur_id: number;
    score_obtenu: number;
    commentaire?: string;
  }[]): Promise<{ data: { message: string; scores: any[] } }> => 
    api.post('/indicateur-scores', scoresData),

  // NOUVELLE FONCTION: Récupérer l'historique des évaluations d'un utilisateur
  getEvaluationHistory: (userId: number): Promise<{ data: EvaluationSession[] }> => 
    api.get(`/evaluation-history/${userId}`),

  // NOUVELLE FONCTION: Récupérer les données complètes d'une évaluation
  getFullEvaluationData: (evaluationId: number): Promise<{ data: Evaluation }> => 
    api.get(`/evaluation-data/${evaluationId}`),

  

  //system

  createSystemEvaluation: (data: {
  user: {
    nom: string;
    prenom: string;
    email: string;
    telephone: string;
    ville: string;
    pays: string;
  };
  evaluation_ids: number[];
}): Promise<{ data: { user: User; sessions: EvaluationSession[] } }> => 
  api.post('/system-evaluation', data),

  // Récupérer une session système spécifique
 getSessionsScores: (sessionIds: number[]): Promise<{ data: SessionScore[] }> => 
    api.post('/sessions/scores', { sessionIds }),
  
};

export default api;