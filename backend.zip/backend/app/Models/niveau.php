<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\indicateur;

class niveau extends Model
{
    //
     protected $table='niveaux';
     protected $fillable = [
        'indicateur_id',
        'nom',
        'value',
    ];

    //Un niveau appartient a un indicateur
    public function indicateur(){
        return $this->belongsTo(indicateur::class, 'indicateur_id', 'id');
    }
}
