<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
     protected $table='users';

    protected $fillable = [
        'nom',
        'prenom',
        'email',
        'telephone',
        'ville',
        'pays',
    ];

    // Un utilisateur peut avoir plusieurs sessions d'évaluation
    public function evaluationSessions() {
        return $this->hasMany(evaluation_session::class);
    }
}
