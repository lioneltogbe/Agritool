<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\evaluation_session;

class evaluation extends Model
{
   protected $fillable = [
        'titre',
        'type',
        'categorie_id',
        'souscategorie_id',
    ];
    // Une évaluation peut correspondre à plusieurs évaluations_sessions
    public function indicateurScores() {
        return $this->hasMany(evaluation_session::class);
    }

    // Une évaluation appartient à une sous-catégorie
    public function souscategorie(){
        return $this->belongsTo(souscategorie::class, 'souscategorie_id','id');
    }
    // Une évaluation appartient à une catégorie
    public function categorie(){
        return $this->belongsTo(categorie::class, 'categorie_id','id');
    }
}
