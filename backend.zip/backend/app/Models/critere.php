<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\categorie;
use App\Models\indicateur;

class critere extends Model
{
    protected $fillable = [
        'categorie_id',
        'nom',
    ];
    //une critere appartient a une categorie
    public function categorie(){
        return $this->belongsTo(categorie::class, 'categorie_id', 'id');
    }
    //Un critere peut avoir plusieurs indicateurs
    public function indicateurs(){
        return $this->hasMany(indicateur::class);
    }
}
