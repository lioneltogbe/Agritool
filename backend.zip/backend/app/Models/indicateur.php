<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\critere;
use App\Models\indicateur_score;
use App\Models\niveau;

class indicateur extends Model
{
    protected $fillable = [
        'critere_id',
        'nom',
        'poids',
    ];

    //Un indicateur appartient a un critère
    public function critere(){
        return $this->belongsTo(critere::class, 'critere_id', 'id');
    }
    //Un indicateur peut avoir plusieurs indicateur_scores
    public function indicateurScores() {
         return $this->hasMany(indicateur_score::class);
    }
    //un indicateur correspond à plusieurs niveaux
    public function niveaux(){
        return $this->hasMany(niveau::class);
    }
}
