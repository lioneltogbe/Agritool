<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\indicateur_score;
use App\Models\User;
use App\Models\evaluation;

class evaluation_session extends Model
{
    //
    protected $fillable = [
        'user_id',
        'evaluation_id',
        'type',
        'date_evaluation',
    ];

    // Une evaluation_session peut avoir plusieurs indicateurs_scores
    public function indicateurScores() {
        return $this->hasMany(indicateur_score::class);
    }

    // Une evaluation_session appartient à un utilisateur
    public function user(){
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
    // Une evaluation_session appartient à une évaluation
    public function evaluation(){
        return $this->belongsTo(evaluation::class, 'evaluation_id', 'id');
    }
}
