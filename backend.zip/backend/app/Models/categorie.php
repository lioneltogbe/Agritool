<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\critere;

class categorie extends Model
{
    protected $fillable = [
        'nom',
    ];

    //Une categorie peut avoir plusieurs criteres
    public function criteres () {
        return $this->hasMany(critere::class);
    }
}
