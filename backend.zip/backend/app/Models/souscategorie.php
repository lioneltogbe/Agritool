<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class souscategorie extends Model
{
      protected $fillable = [
        'categorie_id',
        'nom',
    ];

    //une souscategorie appartient a une categorie
    public function categorie(){
        return $this->belongsTo(categorie::class, 'categorie_id', 'id');
    }
    //Une souscategorie peut avoir plusieurs evaluations
    public function evaluations(){
        return $this->hasMany(evaluation::class);
    }
}
