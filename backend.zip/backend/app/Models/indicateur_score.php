<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\indicateur;
use App\Models\evaluation_session;

class indicateur_score extends Model
{   protected $table='indicateur_scores';
    protected $fillable = [
        'session_id',
        'indicateur_id',
        'score_obtenu',
    ];

    // Un indicateur_score à une évaluation_session et un indicateur
    public function evaluationSession() {
        return $this->belongsTo(evaluation_session::class, 'session_id', 'id');
    }
    public function indicateur() {
        return $this->belongsTo(indicateur::class, 'indicateur_id', 'id');
    }
}
