<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\categorie;
use App\Models\critere;
use App\Models\indicateur;
use App\Models\evaluation;
use App\Models\niveau;

class Controllerapi extends Controller
{
    public function getCategories()
    {
        $categories=categorie::all();
        return response()->json($categories);
    }

    //evaluation par categorie
    public function getByCategory($categoryId){

        $evaluations= evaluation::where('categorie_id', $categoryId)->get();
        return response()->json($evaluations);

    }

    //recuperer une evaluation avec ces données
    public function getEvaluation($evaluationId){
        $evaluation=evaluation::find($evaluationId);
        return response()->json($evaluation);
    }

    //critere par evaluation
    public function getCriteres($categoryId){
        $criteres=critere::where('categorie_id', $categoryId)->get();
        return response()->json($criteres);
    }

    //indicateur par critere
    public function getIndicateur($critereId){
        $indicateur=indicateur::where('critere_id', $critereId)->get();
        return response()->json($indicateur);
    }
    //niveau par indicateur
    public function getNiveau($indicateurId){
        $niveaux=niveau::where('indicateur_id', $indicateurId)->get();
        return response()->json($niveaux);
    }
}
