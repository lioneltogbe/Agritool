<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\evaluation_session;
use App\Models\indicateur_score;
use App\Models\categorie;
use App\Models\critere;
use App\Models\indicateur;
use App\Models\evaluation;
use App\Models\niveau;
use App\Models\souscategorie;
use Illuminate\Support\Facades\Log;

class apiController extends Controller
{
     public function getCategories()
    {
        $categories=categorie::all();
        return response()->json($categories);
    }

    //souscategorie par categorie
    public function getSousCategories($categoryId){
        $souscategories=souscategorie::where('categorie_id', $categoryId)->get();
        return response()->json($souscategories);
    }

    //evaluation par categorie
    public function getByCategory($categoryId){

        $evaluations= evaluation::where('categorie_id', $categoryId)->get();
        return response()->json($evaluations);

    }

    //evaluiation par souscategorie
    public function getBySousCategory($souscategoryId){
        $evaluations= evaluation::where('souscategorie_id', $souscategoryId)->get();
        return response()->json($evaluations);
    }


    //recuperer une evaluation avec ces données
    public function getEvaluation($id){

        $evaluation= evaluation::Find($id);
        return response()->json($evaluation);
    }

    //critere par evaluation
    public function getCriteres($categoryId){
        $criteres =critere::where('categorie_id', $categoryId)->get();
        return response()->json($criteres);
    }

    //indicateur par critere
    public function getIndicateur($critereId){
        $indicateur=indicateur::where('critere_id', $critereId)->get();
        return response()->json($indicateur);
    }
    //niveau par indicateur
    public function getNiveau($indicateurId){
        $niveaux=niveau::where('indicateur_id', $indicateurId)->get();
        return response()->json($niveaux);
    }
      // Créer un utilisateur et une session d'évaluation en une seule opération
    public function createUserAndSession(Request $request)
    {
        // Validation des données
        $validator = Validator::make($request->all(), [
            'user.nom' => 'required|string|max:100',
            'user.prenom' => 'required|string|max:100',
            'user.email' => 'required|email|',
            'user.telephone' => 'required|string|',
            'user.ville' => 'required|string|max:100',
            'user.pays' => 'required|string|max:100',
            'evaluation_id' => 'required|exists:evaluations,id'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => 'Données invalides',
                'details' => $validator->errors()
            ], 422);
        }

        try {
            DB::beginTransaction();

            // Création de l'utilisateur
            $user = User::create([
                'nom' => $request->input('user.nom'),
                'prenom' => $request->input('user.prenom'),
                'email' => $request->input('user.email'),
                'telephone' => $request->input('user.telephone'),
                'ville' => $request->input('user.ville'),
                'pays' => $request->input('user.pays'),

            ]);

            // Création de la session d'évaluation
            $session = evaluation_session::create([

                'user_id' => $user->id,
                'evaluation_id' => $request->input('evaluation_id'),
                'type'=> '',
                'date_evaluation' => now()
            ]);

            DB::commit();

            return response()->json([
                'session' => $session,
                'user' => $user
            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'error' => 'Erreur lors de la création',
                'message' => 'Erreur pour enregister cest ici'
            ], 500);
        }
    }

    // Sauvegarder les scores des indicateurs
    public function saveIndicatorScores(Request $request)
    {



       //Validation des données
        $validator = Validator::make($request->all(), [
            '*.session_id' => 'required|exists:evaluation_sessions,id',
            '*.indicateur_id' => 'required|exists:indicateurs,id',
            '*.score_obtenu' => 'required|numeric|min:1|max:5',
            '*.commentaire' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => 'Données de score invalides',
                'details' => $validator->errors()
            ], 422);
        }

        try {
            $scores = [];

            foreach ($request->all() as $scoreData) {
                $score = indicateur_score::create([
                    'session_id' => $scoreData['session_id'],
                    'indicateur_id' => $scoreData['indicateur_id'],
                    'score_obtenu' => $scoreData['score_obtenu'],
                    'commentaire' => '',
                ]);

                $scores[] = $score;
            }

            return response()->json([
                'message' => 'Scores enregistrés avec succès',
                'scores' => $scores
            ], 201);

        } catch (\Exception $e) {
            Log::error('Erreur de création'.$e->getMessage());
            return response()->json([
                'error' => 'Erreur lors de l\'enregistrement des scores',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    // Récupérer l'historique des évaluations d'un utilisateur
    public function getEvaluationHistory($userId)
    {
        $sessions = evaluation_session::with(['evaluation', 'indicateurScores'])
            ->where('user_id', $userId)
            ->orderBy('date_evaluation', 'desc')
            ->get();

        return response()->json($sessions);
    }

    // Récupérer les données complètes d'une évaluation
    public function getFullEvaluationData($evaluationId)
    {
        $evaluation = evaluation::with(['categorie.criteres.indicateurs.niveaux'])
            ->find($evaluationId);

        if (!$evaluation) {
            return response()->json([
                'error' => 'Évaluation non trouvée'
            ], 404);
        }

        return response()->json($evaluation);
    }

}
