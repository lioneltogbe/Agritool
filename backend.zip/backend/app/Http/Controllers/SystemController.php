<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\evaluation_session;
use App\Models\indicateur_score;
use Illuminate\Support\Facades\DB;
class SystemController extends Controller
{
    public function createSystemEvaluation(Request $request)
{
    $validated = $request->validate([
        'user' => 'required|array',
        'user.nom' => 'required|string',
        'user.prenom' => 'required|string',
        'user.email' => 'required|email',
        'user.telephone' => 'required|string',
        'user.ville' => 'required|string',
        'user.pays' => 'required|string',
        'evaluation_ids' => 'required|array|size:2',
        'evaluation_ids.*' => 'exists:evaluations,id'
    ]);

    // Créer l'utilisateur
   // $user = User::create($validated['user']);

     $user = User::create([
                'nom' => $request->input('user.nom'),
                'prenom' => $request->input('user.prenom'),
                'email' => $request->input('user.email'),
                'telephone' => $request->input('user.telephone'),
                'ville' => $request->input('user.ville'),
                'pays' => $request->input('user.pays')
            ]);

    // Créer les deux sessions de type système
    $sessions = [];
    foreach ($validated['evaluation_ids'] as $evaluationId) {
        $session = evaluation_session::create([
            'user_id' => $user->id,
            'evaluation_id' => $evaluationId,
            'type' => 'system',
            'date_evaluation' => now()
        ]);
        $sessions[] = $session;
    }

    return response()->json([
        'user' => $user,
        'sessions' => $sessions
    ], 201);
}

public function getSessionsScores(Request $request)
    {
        $request->validate([
            'sessionIds' => 'required|array',
            'sessionIds.*' => 'integer|exists:evaluation_sessions,id'
        ]);

        $sessionIds = $request->sessionIds;

        // Récupérer tous les scores pour les sessions données
        $scores = indicateur_score::whereIn('session_id', $sessionIds)->get();

        // Structurer les données par session
        $result = [];
        foreach ($sessionIds as $sessionId) {
            $sessionScores = $scores->where('session_id', $sessionId);
            $scoreMap = [];
            foreach ($sessionScores as $score) {
                $scoreMap[$score->indicateur_id] = $score->score_obtenu;
            }
            $result[] = [
                'session_id' => $sessionId,
                'scores' => $scoreMap
            ];
        }

        return response()->json($result);
    }
}
