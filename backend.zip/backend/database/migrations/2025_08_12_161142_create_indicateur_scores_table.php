<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('indicateur_scores', function (Blueprint $table) {
            $table->id();
            $table->integer('session_id');
            $table->integer('indicateur_id');
            $table->float('score_obtenu');
            $table->text('commentaire')->nullable();
            $table->timestamps();
            $table->primary('id');
            $table->foreign('session_id')->references('id')->on('evaluations_sessions')->onDelete('cascade');
            $table->foreign('indicateur_id')->references('id')->on('indicateurs')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('indicateur_scores');
    }
};
