<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   public function up()
{
    Schema::create('evaluation_sessions', function (Blueprint $table) {
        $table->id();
        $table->integer('user_id');
        $table->integer('evaluation_id');
         $table->dateTime('date_evaluation')->useCurrent();
        $table->timestamps();
        $table->primary('id');
        $table->foreign('evaluation_id')->references('id')->on('evaluations')->onDelete('cascade');
        $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
    });
}


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
