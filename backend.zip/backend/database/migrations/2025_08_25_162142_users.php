<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up() {
    Schema::create('users', function (Blueprint $table) {
        $table->id();
        $table->string('nom', 100);
        $table->string('prenom', 100);
        $table->string('email', 150)->unique();
        $table->string('telephone', 20)->nullable();
        $table->string('localisation', 255)->nullable();
        $table->timestamps();
    });
}


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
