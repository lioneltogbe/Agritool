<?php

use App\Http\Controllers\api\apiController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SystemController;



Route::get('/categories', [apiController::class, 'getCategories'] );
Route::get('/evaluations/{categoryId}', [apiController::class, 'getByCategory']);
Route::get('/evaluation/{id}', [apiController::class, 'getEvaluation']);
Route::get('/criteres/{categoryId}', [apiController::class, 'getCriteres']);
Route::get('/indicateur/{critereId}', [apiController::class, 'getIndicateur']);
Route::get('/niveau/{indicateurId}', [apiController::class, 'getNiveau']);
Route::post('/users-with-session', [apiController::class, 'createUserAndSession']);
Route::post('/indicateur-scores', [apiController::class, 'saveIndicatorScores']);
Route::get('/evaluation-history/{userId}', [apiController::class, 'getEvaluationHistory']);
Route::get('/evaluation-data/{evaluationId}', [apiController::class, 'getFullEvaluationData']);

Route::get('/souscategories/{categoryId}', [apiController::class, 'getSousCategories'] );
Route::get('/souscategorie-evaluations/{souscategoryId}', [apiController::class, 'getBySousCategory'] );

// Routes pour le système d'évaluation

// Créer un utilisateur et deux session système
Route::post('/system-evaluation', [SystemController::class, 'createSystemEvaluation']);

// Récupérer les scores pour plusieurs sessions
Route::post('/sessions/scores', [SystemController::class, 'getSessionsScores']);
Route::prefix('system')->group(function () {


    // Gestion des sessions système
    Route::get('/sessions/{id}', [SystemController::class, 'getSystemSession']);
    Route::put('/sessions/{id}', [SystemController::class, 'updateSystemSession']);
    Route::delete('/sessions/{id}', [SystemController::class, 'deleteSystemSession']);

    // Sauvegarde des scores
    Route::post('/scores', [SystemController::class, 'saveSystemScores']);

    // Historique et données
    Route::get('/user/{userId}/sessions', [SystemController::class, 'getUserSystemSessions']);
    Route::get('/session-data/{sessionId}', [SystemController::class, 'getFullSystemSessionData']);
});



?>
